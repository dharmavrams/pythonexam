import pandas as pd

df = pd.read_csv('data.csv')  # Assume data.csv is available
print("Full:
", df)
print("Specific Rows:
", df.iloc[0:2])
print("Specific Columns:
", df[['Name']])
print("Specific Row+Col:
", df.loc[0, 'Name'])
