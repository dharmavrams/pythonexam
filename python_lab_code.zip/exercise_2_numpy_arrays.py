import numpy as np

# a. Create and display 1D array
arr1 = np.array([1, 2, 3])
print("1D Array:", arr1)

# b. Matrix addition, subtraction, multiplication
A = np.array([[1, 2], [3, 4]])
B = np.array([[5, 6], [7, 8]])
print("Addition:
", A + B)
print("Subtraction:
", A - B)
print("Multiplication:
", np.dot(A, B))

# c. Slicing a matrix
print("Sliced:
", A[:, 1])

# d. Transpose
print("Transpose:
", A.T)
