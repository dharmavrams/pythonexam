import pandas as pd
import numpy as np

df = pd.DataFrame({'A': [1, np.nan, 3], 'B': [4, 5, np.nan]})
print("Original:
", df)

# Check missing
print("Is Null:
", df.isnull())

# Fill missing
print("Filled:
", df.fillna(0))

# Drop missing
print("Dropped:
", df.dropna())
