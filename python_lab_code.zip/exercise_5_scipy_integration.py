from scipy import integrate
import numpy as np

# Single
res1, _ = integrate.quad(lambda x: x**2, 0, 1)
print("Single:", res1)

# Double
res2, _ = integrate.dblquad(lambda x, y: x*y, 0, 1, lambda x: 0, lambda x: 2)
print("Double:", res2)

# Triple
res3, _ = integrate.tplquad(lambda x, y, z: x*y*z, 0, 1, lambda x: 0, lambda x: 1, lambda x, y: 0, lambda x, y: 1)
print("Triple:", res3)
