import matplotlib.pyplot as plt
import numpy as np

# Line chart
x = np.linspace(0, 10, 100)
y = np.sin(x)
plt.plot(x, y)
plt.xlabel('x')
plt.ylabel('sin(x)')
plt.title('Line Chart')
plt.savefig('line_chart.png')
plt.close()

# Box plot
plt.boxplot(np.random.randn(100))
plt.savefig('boxplot.png')
plt.close()

# Scatter plot
plt.scatter(np.random.rand(10), np.random.rand(10))
plt.savefig('scatter.png')
plt.close()

# Bubble chart
x = np.random.rand(10)
y = np.random.rand(10)
size = np.random.rand(10) * 300
plt.scatter(x, y, s=size, alpha=0.5)
plt.savefig('bubble.png')
plt.close()

# 3D plot
from mpl_toolkits.mplot3d import Axes3D
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
x = y = np.linspace(-5, 5, 100)
X, Y = np.meshgrid(x, y)
Z = np.sin(np.sqrt(X**2 + Y**2))
ax.plot_surface(X, Y, Z, cmap='viridis')
plt.savefig('3dplot.png')
plt.close()
