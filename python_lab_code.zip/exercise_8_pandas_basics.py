import pandas as pd

# Series
s = pd.Series([1, 2, 3])
print("Series:", s)

# DataFrame
data = {'Name': ['Alice', 'Bob'], 'Age': [25, 30]}
df = pd.DataFrame(data)
print("DataFrame:
", df)
