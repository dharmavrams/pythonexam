# Server
# Run this in one terminal
import socket

server_socket = socket.socket()
server_socket.bind(('localhost', 12345))
server_socket.listen(1)
print("Server listening...")
conn, addr = server_socket.accept()
print("Connected by", addr)
data = conn.recv(1024)
conn.sendall(data)
conn.close()

# Client
# Run this in another terminal
import socket

client_socket = socket.socket()
client_socket.connect(('localhost', 12345))
client_socket.sendall(b'Hello, Server!')
data = client_socket.recv(1024)
print("Received:", data.decode())
client_socket.close()
