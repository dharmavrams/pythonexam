from scipy import interpolate
import numpy as np

# 1D interpolation
x = np.linspace(0, 10, 10)
y = np.sin(x)
f = interpolate.interp1d(x, y)
print("Interpolated:", f(5.5))

# Multivariate
from scipy.interpolate import griddata
points = np.array([[0, 0], [1, 0], [0, 1], [1, 1]])
values = np.array([0, 1, 1, 0])
grid_x, grid_y = np.mgrid[0:1:5j, 0:1:5j]
result = griddata(points, values, (grid_x, grid_y), method='linear')
print("Grid:
", result)
