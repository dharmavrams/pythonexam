import numpy as np

arr = np.array([10, 20, 30])
np.save("saved_array.npy", arr)

loaded = np.load("saved_array.npy")
print("Loaded array:", loaded)
