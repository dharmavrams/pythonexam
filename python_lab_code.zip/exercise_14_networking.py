import socket

# a. Local machine name and IP
print("Hostname:", socket.gethostname())
print("Local IP:", socket.gethostbyname(socket.gethostname()))

# b. Remote machine IP
print("Google IP:", socket.gethostbyname('www.google.com'))

# c. IPv4 conversion
ip = '192.168.1.1'
packed_ip = socket.inet_aton(ip)
print("Packed IP:", packed_ip)

# d. Service name
print("Service on port 80:", socket.getservbyport(80, 'tcp'))

# e. Byte order conversion
print("Host to network (16-bit):", socket.htons(1234))
print("Network to host (32-bit):", socket.ntohl(12345678))
